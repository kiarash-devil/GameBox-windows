const { app, BrowserWindow, shell, session, Menu, protocol, desktopCapturer } = require('electron');
const path = require('path');
const fs = require('fs');

// Serve the game from a secure, standard origin (app://game) instead of file://.
// Games run inside blob: iframes, which do not load from a file:// origin.
protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }
]);

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 800, minWidth: 800, minHeight: 560,
    backgroundColor: '#0b1026',
    autoHideMenuBar: true,
    title: 'Game Box',
    icon: path.join(__dirname, 'build', 'icon.ico'),
    webPreferences: { contextIsolation: true, nodeIntegration: false }
  });
  Menu.setApplicationMenu(null);
  win.loadURL('app://game/index.html');
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('app://')) {
      e.preventDefault();
      if (/^https?:/.test(url)) shell.openExternal(url);
    }
  });
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type === 'keyDown' && i.key === 'F11') win.setFullScreen(!win.isFullScreen());
  });
}

app.whenReady().then(() => {
  protocol.handle('app', () => {
    const data = fs.readFileSync(path.join(__dirname, 'index.html'));
    return new Response(data, { headers: { 'content-type': 'text/html; charset=utf-8' } });
  });
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) =>
    cb(['media', 'display-capture', 'fullscreen', 'clipboard-sanitized-write'].includes(perm)));

  // Screen share (getDisplayMedia) is not built into Electron: pick a screen/window ourselves.
  session.defaultSession.setDisplayMediaRequestHandler((request, callback) => {
    desktopCapturer.getSources({ types: ['screen', 'window'] }).then(sources => {
      if (!sources.length) return callback({});
      let chosen = false;
      const done = src => {
        chosen = true;
        // 'loopback' = capture system audio on Windows
        callback(src ? { video: src, audio: 'loopback' } : {});
      };
      const menu = Menu.buildFromTemplate([
        { label: 'Share which screen / window?', enabled: false },
        { type: 'separator' },
        ...sources.map(src => ({ label: src.name.slice(0, 60), click: () => done(src) }))
      ]);
      menu.popup({ callback: () => setTimeout(() => { if (!chosen) done(null); }, 200) });
    }).catch(() => callback({}));
  });
  createWindow();
});
app.on('window-all-closed', () => app.quit());
